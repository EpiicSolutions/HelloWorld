﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PartsUnlimited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartsUnlimited.Tests
{
    [TestClass()]
    public class StartupTests
    {
        [TestMethod()]
        public void Sel_IE_Shopping()
        {
           Assert.Fail();
        }

        
        [TestMethod()]
        public void Sel_Fox_Shopping()
        {//
            //Assert.Fail();
        }
        [TestMethod()]
        public void Sel_Chrome_Shopping()
        {
            //Assert.Fail();
        }

        [TestMethod()]
        public void Sel_IE_Admin()
        {
            Assert.Fail();
        }


        [TestMethod()]
        public void Sel_Fox_Identity()
        {
            // Assert.Fail();
        }

        [TestMethod()]
        public void Sel_Fox_Admin()
        {
           // Assert.Fail();
        }
        [TestMethod()]
        public void Sel_Chrome_Admin()
        {
           //Assert.Fail();
        }

        [TestMethod()]
        public void Sel_Chrome_Identity()
        {
            //Assert.Fail();
        }

        [TestMethod()]
        public void Sel_IE_Browse()
        {
            Assert.Fail();
        }


        [TestMethod()]
        public void Sel_Fox_Browse()
        {
            //Assert.Fail();
        }
        [TestMethod()]
        public void Sel_Chrome_Browse()
        {
            //Assert.Fail();
        }

    }
}
